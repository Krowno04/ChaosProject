using UnityEngine;

public class UnitController : MonoBehaviour
{
    public string unitName;
    public int unitLevel;

    public int damage;

    public int healthMax;
    public int healthCurrent;

    public int speedBase;
    public int speedCurrent;
}

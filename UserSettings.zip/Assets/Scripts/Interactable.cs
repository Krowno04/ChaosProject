using UnityEngine;

public interface Interactable
{
    void Interact();

}
